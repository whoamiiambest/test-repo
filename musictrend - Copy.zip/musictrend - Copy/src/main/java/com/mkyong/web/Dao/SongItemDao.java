package com.mkyong.web.Dao;

import com.mkyong.web.pojo.SongItem;

public interface SongItemDao {
	public SongItem GetSongItem(String id);
}
