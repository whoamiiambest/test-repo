package com.mkyong.web.config;


public class CONFIG {
	
	public static final String GET_TOP_100SONG_ZING_URL = "http://mp3.zing.vn/html5xml/album-xml/kHxHyLmsVJimxAgyZFctDHkm";
	public static final String GET_TOTAL_LISTEN_URL = "http://mp3.zing.vn/json/song/listen?id=";
	public static final String PHOTO_ROOT = "http://zmp3-photo.d.za.zdn.vn";
	public static final String MUSIC_ROOT = "http://mp3.zing.vn";
	
	public static final String DB_NAME = "musictrend";
}

